#ifndef _FFFFF_H
#define _FFFFF_H

#include "config.h"

@

#endif /* _FFFFF_H */
